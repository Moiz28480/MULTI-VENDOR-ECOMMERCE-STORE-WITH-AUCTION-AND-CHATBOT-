import { Client, Databases, ID } from 'node-appwrite';
import { GoogleGenerativeAI } from '@google/generative-ai';

const DATABASE_ID = process.env.DATABASE_ID || '69c1cfaf003a710f1232';
const COLLECTION_ID = 'chat_messages';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';

const SYSTEM_PROMPTS = {
  Customer: `You are a helpful customer service assistant for an online marketplace. Your role is to help customers with:
- Finding and recommending products based on their needs
- Explaining how to use the auction system
- Tracking orders and checking order status
- Resolving account and login issues
- Filing complaints and feedback
- Explaining shipping and return policies

Be friendly, concise, and helpful. If a customer asks about a specific product, provide recommendations with product names. For auctions, explain how bidding works, end times, and how to place bids.`,

  Vendor: `You are a helpful assistant for vendors/sellers on the marketplace. Your role is to help vendors with:
- Managing their product listings and inventory
- Understanding auction dashboard features
- Setting up retail vs auction listings
- Monitoring bids and auction status
- Shipping and fulfillment guidance
- Account and profile management
- Understanding seller policies and commission structures

Be professional and technical. Help vendors optimize their listings and understand platform features.`,

  Admin: `You are an administrative assistant for marketplace administrators. Your role is to help admins with:
- User and vendor management
- Dispute and complaint resolution procedures
- System monitoring and health checks
- Escalation procedures for critical issues
- Policy enforcement and moderation
- Analytics and reporting guidance
- Database and collection management

Provide clear, technical guidance and escalation pathways.`,
};

const CUSTOMER_CONTEXT_PROMPT = `You have access to the customer's current context:
- Recent orders (if any)
- Wishlist items (if any)
- Current auctions they're bidding on (if any)

When relevant, reference this information to provide personalized recommendations.`;

const VENDOR_CONTEXT_PROMPT = `You have access to the vendor's current context:
- Active listings count
- Active auctions count
- Recent order volume
- Customer rating

Use this information to provide relevant guidance on inventory management and sales optimization.`;

const json = (res, statusCode, body) => {
  res.json(body, statusCode);
};

const parseUserMessage = (text) => {
  if (!text) return '';
  return String(text).trim();
};

const parseChatHistory = (messages = []) => {
  return messages
    .slice(-20)
    .map((msg) => ({
      role: msg?.role || 'user',
      content: msg?.content || '',
    }))
    .filter((msg) => msg.content);
};

export default async function (req, res, { log, error }) {
  log('Chatbot function invoked');

  if (req.method !== 'POST') {
    return json(res, 405, { ok: false, message: 'Only POST requests are supported.' });
  }

  let payload;
  try {
    payload = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch {
    return json(res, 400, { ok: false, message: 'Invalid JSON payload.' });
  }

  const { user_id, role, message, history = [] } = payload;

  if (!user_id || !role || !message) {
    return json(res, 400, {
      ok: false,
      message: 'Required fields: user_id, role, message.',
    });
  }

  if (!GEMINI_API_KEY) {
    return json(res, 500, {
      ok: false,
      message: 'Gemini API key not configured.',
    });
  }

  const cleanMessage = parseUserMessage(message);
  if (!cleanMessage) {
    return json(res, 400, { ok: false, message: 'Message cannot be empty.' });
  }

  const roleKey = String(role || 'Customer').trim();
  const systemPrompt = SYSTEM_PROMPTS[roleKey] || SYSTEM_PROMPTS.Customer;
  const contextNote = roleKey === 'Vendor' ? VENDOR_CONTEXT_PROMPT : roleKey === 'Admin' ? '' : CUSTOMER_CONTEXT_PROMPT;
  const fullSystemPrompt = `${systemPrompt}\n\n${contextNote}`.trim();

  try {
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const chatHistory = parseChatHistory(history);

    const chat = model.startChat({
      history: chatHistory.map((msg) => ({
        role: msg.role,
        parts: [{ text: msg.content }],
      })),
      generationConfig: {
        maxOutputTokens: 1024,
        temperature: 0.7,
      },
    });

    const result = await chat.sendMessage(cleanMessage);
    const responseText = result.response.text() || '';

    if (!responseText) {
      return json(res, 500, {
        ok: false,
        message: 'Failed to generate response from AI model.',
      });
    }

    // Store message in Appwrite (if database available)
    const messageDoc = {
      user_id: String(user_id).trim(),
      role: roleKey,
      user_message: cleanMessage,
      ai_response: responseText,
      timestamp: new Date().toISOString(),
      metadata: {
        model: 'gemini-pro',
        temperature: 0.7,
      },
    };

    try {
      const client = new Client()
        .setEndpoint(process.env.APPWRITE_ENDPOINT || 'https://nyc.cloud.appwrite.io/v1')
        .setProject(process.env.APPWRITE_PROJECT_ID || '69bf4532001c55de99e2')
        .setKey(process.env.APPWRITE_API_KEY || '');

      const databases = new Databases(client);

      await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), messageDoc);
      log(`Chat message stored for user ${user_id}`);
    } catch (dbError) {
      log(`Warning: Failed to store chat message: ${dbError?.message || dbError}`);
    }

    return json(res, 200, {
      ok: true,
      message: responseText,
      timestamp: new Date().toISOString(),
      role: roleKey,
    });
  } catch (err) {
    error(`Chatbot failed: ${err?.message || String(err)}`);
    return json(res, 500, {
      ok: false,
      message: err?.message || 'Unexpected error while processing chat.',
    });
  }
}
